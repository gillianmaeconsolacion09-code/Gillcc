
'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Editor() {
  const [currentTime, setCurrentTime] = useState(0);
  const [duration] = useState(120);
  const [playSpeed, setPlaySpeed] = useState(1);
  const [isPlaying, setIsPlaying] = useState(false);
  const [selectedTool, setSelectedTool] = useState('cut');
  const [selectedEffect, setSelectedEffect] = useState('none');

  const tools = [
    { id: 'cut', name: 'Cut', icon: 'ri-scissors-cut-line' },
    { id: 'text', name: 'Text', icon: 'ri-text' },
    { id: 'audio', name: 'Audio', icon: 'ri-volume-up-line' },
    { id: 'effects', name: 'Effects', icon: 'ri-magic-line' },
    { id: '3d', name: '3D', icon: 'ri-3d-view-line' },
    { id: 'animation', name: 'Animation', icon: 'ri-movie-2-line' }
  ];

  const effects = [
    'Motion Blur', 'HDR', 'Cinematic', 'Vintage', 'Particle System',
    'Color Wheel', 'Edge Glow', 'Distortion', '3D Depth', 'Swing'
  ];

  const speedOptions = [0.5, 0.75, 1, 1.25, 1.5, 2, 3];

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="h-screen bg-gray-900 text-white overflow-hidden">
      {/* Header */}
      <header className="bg-gray-800 border-b border-gray-700 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center">
              <i className="ri-film-line text-white text-lg"></i>
            </div>
            <span className="text-xl font-['Pacifico']">GillC</span>
          </Link>
          <div className="text-sm text-gray-400">Professional Video Editor</div>
        </div>
        
        <div className="flex items-center space-x-4">
          <button className="px-4 py-2 bg-gray-700 hover:bg-gray-600 !rounded-button transition-colors">
            <i className="ri-save-line mr-2"></i>Save
          </button>
          <button className="px-4 py-2 bg-gradient-to-r from-blue-500 to-indigo-600 hover:shadow-lg !rounded-button transition-all">
            <i className="ri-download-line mr-2"></i>Export
          </button>
        </div>
      </header>

      <div className="flex h-full">
        {/* Tools Panel */}
        <div className="w-64 bg-gray-800 border-r border-gray-700 p-4 overflow-y-auto">
          <h3 className="text-sm font-semibold text-gray-300 mb-4 uppercase tracking-wide">Tools</h3>
          <div className="space-y-2 mb-6">
            {tools.map((tool) => (
              <button
                key={tool.id}
                onClick={() => setSelectedTool(tool.id)}
                className={`w-full flex items-center space-x-3 px-3 py-2 !rounded-button transition-colors ${
                  selectedTool === tool.id
                    ? 'bg-gradient-to-r from-blue-500 to-indigo-600 text-white'
                    : 'text-gray-300 hover:bg-gray-700'
                }`}
              >
                <i className={`${tool.icon} text-lg`}></i>
                <span>{tool.name}</span>
              </button>
            ))}
          </div>

          {/* Effects Panel */}
          <h3 className="text-sm font-semibold text-gray-300 mb-4 uppercase tracking-wide">Effects</h3>
          <div className="space-y-1">
            {effects.map((effect) => (
              <button
                key={effect}
                onClick={() => setSelectedEffect(effect)}
                className={`w-full text-left px-3 py-2 text-sm !rounded-button transition-colors ${
                  selectedEffect === effect
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-400 hover:bg-gray-700'
                }`}
              >
                {effect}
              </button>
            ))}
          </div>
        </div>

        {/* Main Editor */}
        <div className="flex-1 flex flex-col">
          {/* Preview Area */}
          <div className="flex-1 bg-black relative">
            <div className="absolute inset-4 bg-gray-800 rounded-lg overflow-hidden">
              <div className="w-full h-full relative">
                <img 
                  src="https://readdy.ai/api/search-image?query=Cinematic%20video%20frame%20being%20edited%2C%20professional%20filmmaker%20shooting%20a%20scene%2C%20high-quality%20camera%20equipment%2C%20dramatic%20lighting%2C%20movie%20production%20behind%20the%20scenes%2C%20professional%20videography%2C%20cinematic%20composition&width=800&height=450&seq=editor-preview&orientation=landscape"
                  alt="Video Preview"
                  className="w-full h-full object-cover"
                />
                
                {/* Play Button Overlay */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <button 
                    onClick={() => setIsPlaying(!isPlaying)}
                    className="bg-white/20 backdrop-blur-sm hover:bg-white/30 rounded-full p-4 transition-colors"
                  >
                    <i className={`${isPlaying ? 'ri-pause-fill' : 'ri-play-fill'} text-white text-2xl`}></i>
                  </button>
                </div>

                {/* Speed Control */}
                <div className="absolute top-4 right-4 bg-black/50 backdrop-blur-sm rounded-lg p-2">
                  <div className="flex items-center space-x-2">
                    <i className="ri-speed-line text-white text-sm"></i>
                    <select 
                      value={playSpeed}
                      onChange={(e) => setPlaySpeed(parseFloat(e.target.value))}
                      className="bg-transparent text-white text-sm outline-none"
                    >
                      {speedOptions.map(speed => (
                        <option key={speed} value={speed} className="bg-gray-800">
                          {speed}x
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Timeline Indicator */}
                <div className="absolute bottom-4 left-4 right-4">
                  <div className="bg-black/50 backdrop-blur-sm rounded-lg p-3">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-white text-sm">{formatTime(currentTime)}</span>
                      <span className="text-white text-sm">{formatTime(duration)}</span>
                    </div>
                    <div className="relative bg-gray-600 rounded-full h-1">
                      <div 
                        className="absolute left-0 top-0 h-full bg-gradient-to-r from-blue-500 to-indigo-600 rounded-full"
                        style={{ width: `${(currentTime / duration) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Timeline Editor */}
          <div className="h-64 bg-gray-800 border-t border-gray-700 p-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-gray-300 uppercase tracking-wide">Timeline</h3>
              <div className="flex items-center space-x-2">
                <button className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 !rounded-button transition-colors">
                  <i className="ri-zoom-in-line"></i>
                </button>
                <button className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 !rounded-button transition-colors">
                  <i className="ri-zoom-out-line"></i>
                </button>
              </div>
            </div>

            {/* Timeline Tracks */}
            <div className="space-y-2">
              {/* Video Track */}
              <div className="flex items-center">
                <div className="w-16 text-xs text-gray-400 uppercase">Video</div>
                <div className="flex-1 bg-gray-700 rounded h-8 relative">
                  <div className="absolute left-2 top-1 bottom-1 w-32 bg-gradient-to-r from-blue-500 to-blue-600 rounded flex items-center px-2">
                    <i className="ri-video-line text-white text-xs mr-1"></i>
                    <span className="text-white text-xs truncate">clip1.mp4</span>
                  </div>
                  <div className="absolute left-36 top-1 bottom-1 w-24 bg-gradient-to-r from-indigo-500 to-indigo-600 rounded flex items-center px-2">
                    <i className="ri-video-line text-white text-xs mr-1"></i>
                    <span className="text-white text-xs truncate">clip2.mp4</span>
                  </div>
                </div>
              </div>

              {/* Audio Track */}
              <div className="flex items-center">
                <div className="w-16 text-xs text-gray-400 uppercase">Audio</div>
                <div className="flex-1 bg-gray-700 rounded h-8 relative">
                  <div className="absolute left-2 top-1 bottom-1 w-40 bg-gradient-to-r from-green-500 to-green-600 rounded flex items-center px-2">
                    <i className="ri-music-line text-white text-xs mr-1"></i>
                    <span className="text-white text-xs truncate">background.mp3</span>
                  </div>
                </div>
              </div>

              {/* Effects Track */}
              <div className="flex items-center">
                <div className="w-16 text-xs text-gray-400 uppercase">Effects</div>
                <div className="flex-1 bg-gray-700 rounded h-8 relative">
                  <div className="absolute left-10 top-1 bottom-1 w-20 bg-gradient-to-r from-purple-500 to-purple-600 rounded flex items-center px-2">
                    <i className="ri-magic-line text-white text-xs mr-1"></i>
                    <span className="text-white text-xs truncate">Blur</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Playback Controls */}
            <div className="flex items-center justify-center space-x-4 mt-4 pt-4 border-t border-gray-700">
              <button className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 !rounded-button transition-colors">
                <i className="ri-skip-back-line"></i>
              </button>
              <button className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 !rounded-button transition-colors">
                <i className="ri-rewind-line"></i>
              </button>
              <button 
                onClick={() => setIsPlaying(!isPlaying)}
                className="p-3 bg-gradient-to-r from-blue-500 to-indigo-600 hover:shadow-lg !rounded-button transition-all"
              >
                <i className={`${isPlaying ? 'ri-pause-fill' : 'ri-play-fill'} text-white`}></i>
              </button>
              <button className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 !rounded-button transition-colors">
                <i className="ri-speed-line"></i>
              </button>
              <button className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 !rounded-button transition-colors">
                <i className="ri-skip-forward-line"></i>
              </button>
            </div>
          </div>
        </div>

        {/* Properties Panel */}
        <div className="w-80 bg-gray-800 border-l border-gray-700 p-4 overflow-y-auto">
          <h3 className="text-sm font-semibold text-gray-300 mb-4 uppercase tracking-wide">Properties</h3>
          
          {selectedTool === 'effects' && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs text-gray-400 mb-2 uppercase">Effect Intensity</label>
                <input 
                  type="range" 
                  min="0" 
                  max="100" 
                  defaultValue="50"
                  className="w-full"
                />
              </div>
              <div>
                <label className="block text-xs text-gray-400 mb-2 uppercase">Blend Mode</label>
                <select className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-sm">
                  <option>Normal</option>
                  <option>Multiply</option>
                  <option>Screen</option>
                  <option>Overlay</option>
                </select>
              </div>
            </div>
          )}

          {selectedTool === '3d' && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs text-gray-400 mb-2 uppercase">Depth</label>
                <input type="range" min="0" max="100" defaultValue="0" className="w-full" />
              </div>
              <div>
                <label className="block text-xs text-gray-400 mb-2 uppercase">Rotation X</label>
                <input type="range" min="-180" max="180" defaultValue="0" className="w-full" />
              </div>
              <div>
                <label className="block text-xs text-gray-400 mb-2 uppercase">Rotation Y</label>
                <input type="range" min="-180" max="180" defaultValue="0" className="w-full" />
              </div>
            </div>
          )}

          {selectedTool === 'animation' && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs text-gray-400 mb-2 uppercase">Animation Type</label>
                <select className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-sm">
                  <option>Fade In</option>
                  <option>Slide Left</option>
                  <option>Zoom In</option>
                  <option>Rotate</option>
                </select>
              </div>
              <div>
                <label className="block text-xs text-gray-400 mb-2 uppercase">Duration (s)</label>
                <input 
                  type="number" 
                  min="0.1" 
                  max="10" 
                  step="0.1" 
                  defaultValue="1.0"
                  className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs text-gray-400 mb-2 uppercase">Easing</label>
                <select className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-sm">
                  <option>Ease In</option>
                  <option>Ease Out</option>
                  <option>Ease In Out</option>
                  <option>Linear</option>
                </select>
              </div>
            </div>
          )}

          {/* Quick Actions */}
          <div className="mt-8">
            <h4 className="text-xs text-gray-400 mb-3 uppercase tracking-wide">Quick Actions</h4>
            <div className="space-y-2">
              <button className="w-full text-left px-3 py-2 text-sm bg-gray-700 hover:bg-gray-600 !rounded-button transition-colors">
                <i className="ri-add-line mr-2"></i>Add Layer
              </button>
              <button className="w-full text-left px-3 py-2 text-sm bg-gray-700 hover:bg-gray-600 !rounded-button transition-colors">
                <i className="ri-file-copy-line mr-2"></i>Duplicate
              </button>
              <button className="w-full text-left px-3 py-2 text-sm bg-gray-700 hover:bg-gray-600 !rounded-button transition-colors">
                <i className="ri-delete-bin-line mr-2"></i>Delete
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
