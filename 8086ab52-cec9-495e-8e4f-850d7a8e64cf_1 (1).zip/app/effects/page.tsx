
'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Effects() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const categories = [
    { id: 'all', name: 'All Effects', count: 400 },
    { id: 'blur', name: 'Blur & Motion', count: 45 },
    { id: 'color', name: 'Color Grading', count: 62 },
    { id: 'distortion', name: 'Distortion', count: 38 },
    { id: 'particles', name: 'Particles', count: 29 },
    { id: '3d', name: '3D Effects', count: 34 },
    { id: 'cinematic', name: 'Cinematic', count: 56 },
    { id: 'vintage', name: 'Vintage', count: 41 },
    { id: 'light', name: 'Light & Glow', count: 33 },
    { id: 'texture', name: 'Texture', count: 27 },
    { id: 'ai', name: 'AI Effects', count: 35 }
  ];

  const effects = [
    {
      id: 1,
      name: 'Motion Blur Pro',
      category: 'blur',
      description: 'Professional motion blur with velocity controls',
      premium: false,
      preview: 'motion-blur-cinematic-video-effect-professional'
    },
    {
      id: 2,
      name: 'HDR Color Grade',
      category: 'color',
      description: 'High dynamic range color enhancement',
      premium: false,
      preview: 'hdr-color-grading-cinematic-film-look-professional'
    },
    {
      id: 3,
      name: 'Particle Storm',
      category: 'particles',
      description: 'Dynamic particle system with physics',
      premium: false,
      preview: 'particle-system-storm-visual-effects-cinematic'
    },
    {
      id: 4,
      name: 'Cinematic LUT',
      category: 'cinematic',
      description: 'Hollywood-style color lookup table',
      premium: false,
      preview: 'cinematic-lut-color-grading-hollywood-film-style'
    },
    {
      id: 5,
      name: '3D Depth Field',
      category: '3d',
      description: 'Realistic depth of field blur',
      premium: false,
      preview: '3d-depth-field-blur-professional-camera-effect'
    },
    {
      id: 6,
      name: 'Vintage Film',
      category: 'vintage',
      description: 'Authentic vintage film grain and color',
      premium: false,
      preview: 'vintage-film-grain-retro-analog-cinema-look'
    },
    {
      id: 7,
      name: 'Edge Glow',
      category: 'light',
      description: 'Luminous edge highlighting effect',
      premium: false,
      preview: 'edge-glow-luminous-highlight-professional-effect'
    },
    {
      id: 8,
      name: 'Turbulent Displace',
      category: 'distortion',
      description: 'Fluid turbulence displacement mapping',
      premium: false,
      preview: 'turbulent-displacement-fluid-distortion-effect'
    },
    {
      id: 9,
      name: 'AI Super Resolution',
      category: 'ai',
      description: 'AI-powered video upscaling',
      premium: false,
      preview: 'ai-super-resolution-upscaling-enhancement'
    },
    {
      id: 10,
      name: 'Swing Dynamics',
      category: 'distortion',
      description: 'Dynamic swing motion effects',
      premium: false,
      preview: 'swing-dynamic-motion-effect-professional'
    },
    {
      id: 11,
      name: 'Primary Color Wheel',
      category: 'color',
      description: 'Professional color wheel correction',
      premium: false,
      preview: 'color-wheel-correction-professional-grading'
    },
    {
      id: 12,
      name: 'Displacement Map',
      category: 'distortion',
      description: 'Advanced displacement mapping',
      premium: false,
      preview: 'displacement-mapping-advanced-distortion'
    }
  ];

  const filteredEffects = effects.filter(effect => {
    const matchesCategory = selectedCategory === 'all' || effect.category === selectedCategory;
    const matchesSearch = effect.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         effect.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-indigo-900">
      {/* Header */}
      <header className="bg-black/20 backdrop-blur-lg border-b border-white/10 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center">
                <i className="ri-film-line text-white text-lg"></i>
              </div>
              <span className="text-2xl font-['Pacifico'] text-white">GillC</span>
            </Link>
            <div className="hidden md:block text-blue-200">400+ Professional Effects</div>
          </div>
          
          <div className="flex items-center space-x-4">
            <Link href="/editor" className="text-blue-200 hover:text-white transition-colors">
              <i className="ri-edit-line mr-2"></i>Editor
            </Link>
            <Link href="/templates" className="text-blue-200 hover:text-white transition-colors">Templates</Link>
            <Link href="/gallery" className="text-blue-200 hover:text-white transition-colors">Gallery</Link>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">
            Professional Effects Library
          </h1>
          <p className="text-xl text-blue-200 mb-8 max-w-3xl mx-auto">
            Over 400 meticulously crafted effects designed by visual effects experts. 
            From motion blur to 3D depth, create Hollywood-quality videos.
          </p>
          
          {/* Search Bar */}
          <div className="max-w-md mx-auto relative mb-8">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search effects..."
              className="w-full bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl px-4 py-3 pl-12 text-white placeholder-blue-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <i className="ri-search-line absolute left-4 top-1/2 transform -translate-y-1/2 text-blue-300"></i>
          </div>
        </div>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Categories Sidebar */}
          <div className="lg:w-64">
            <div className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6 sticky top-24">
              <h3 className="text-white font-semibold mb-4">Categories</h3>
              <div className="space-y-2">
                {categories.map((category) => (
                  <button
                    key={category.id}
                    onClick={() => setSelectedCategory(category.id)}
                    className={`w-full text-left flex items-center justify-between px-3 py-2 rounded-lg transition-colors ${
                      selectedCategory === category.id
                        ? 'bg-gradient-to-r from-blue-500 to-indigo-600 text-white'
                        : 'text-blue-200 hover:bg-white/10'
                    }`}
                  >
                    <span className="text-sm">{category.name}</span>
                    <span className="text-xs opacity-70">{category.count}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Effects Grid */}
          <div className="flex-1">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-white">
                {selectedCategory === 'all' ? 'All Effects' : categories.find(c => c.id === selectedCategory)?.name}
              </h2>
              <div className="text-blue-200">
                {filteredEffects.length} effects
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredEffects.map((effect) => (
                <div
                  key={effect.id}
                  className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 overflow-hidden hover:border-blue-400/50 transition-all group cursor-pointer"
                >
                  {/* Effect Preview */}
                  <div className="aspect-video bg-gradient-to-br from-blue-600 to-indigo-700 relative overflow-hidden">
                    <img 
                      src={`https://readdy.ai/api/search-image?query=$%7Beffect.preview%7D%2C%20professional%20video%20effect%20demonstration%2C%20cinematic%20visual%20effect%2C%20high-quality%20editing%20effect%20preview%2C%20modern%20video%20editing&width=400&height=225&seq=effect-${effect.id}&orientation=landscape`}
                      alt={effect.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                      <div className="absolute inset-0 flex items-center justify-center">
                        <button className="bg-white/20 backdrop-blur-sm rounded-full p-3 hover:bg-white/30 transition-colors">
                          <i className="ri-play-fill text-white text-xl"></i>
                        </button>
                      </div>
                    </div>
                    {!effect.premium && (
                      <div className="absolute top-3 left-3 bg-green-500 text-white text-xs px-2 py-1 rounded-full font-medium">
                        FREE
                      </div>
                    )}
                  </div>

                  {/* Effect Info */}
                  <div className="p-4">
                    <h3 className="text-white font-semibold mb-2">{effect.name}</h3>
                    <p className="text-blue-200 text-sm mb-3">{effect.description}</p>
                    
                    <div className="flex items-center justify-between">
                      <div className="text-xs text-blue-300 capitalize">
                        {categories.find(c => c.id === effect.category)?.name}
                      </div>
                      <button className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white px-4 py-2 !rounded-button text-sm hover:shadow-lg transition-all">
                        Apply Effect
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Load More */}
            <div className="text-center mt-12">
              <button className="bg-white/10 backdrop-blur-sm text-white px-8 py-3 !rounded-button border border-white/20 hover:bg-white/20 transition-all">
                Load More Effects
              </button>
            </div>
          </div>
        </div>

        {/* Featured Section */}
        <section className="mt-16">
          <div className="bg-gradient-to-r from-blue-600/20 to-indigo-600/20 backdrop-blur-sm rounded-2xl border border-white/10 p-8">
            <div className="text-center">
              <h2 className="text-3xl font-bold text-white mb-4">Create Your Own Effects</h2>
              <p className="text-blue-200 mb-6 max-w-2xl mx-auto">
                Use our advanced effect composer to create custom effects with keyframes, 
                curves, and professional controls. Save and share with the community.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link href="/editor" className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white px-6 py-3 !rounded-button hover:shadow-lg transition-all">
                  <i className="ri-add-line mr-2"></i>
                  Create Effect
                </Link>
                <button className="bg-white/10 backdrop-blur-sm text-white px-6 py-3 !rounded-button border border-white/20 hover:bg-white/20 transition-all">
                  <i className="ri-download-line mr-2"></i>
                  Download Pack
                </button>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
