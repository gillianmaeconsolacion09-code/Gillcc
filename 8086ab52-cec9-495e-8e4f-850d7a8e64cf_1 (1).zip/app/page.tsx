
'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Home() {
  const [activeFeature, setActiveFeature] = useState(0);

  const features = [
    {
      title: "Professional Video Editing",
      description: "Timeline controls, cutting tools, and audio sync",
      icon: "ri-movie-2-line"
    },
    {
      title: "400+ Visual Effects",
      description: "Motion Blur, HDR, Particle Systems, and more",
      icon: "ri-magic-line"
    },
    {
      title: "3D Templates & Editor",
      description: "Logo reveals, text animations, and 3D depth controls",
      icon: "ri-3d-view-line"
    },
    {
      title: "AI-Powered Tools",
      description: "Smart cutout, frame interpolation, and auto-editing",
      icon: "ri-robot-2-line"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* Header */}
      <header className="fixed top-0 w-full bg-white/90 backdrop-blur-lg border-b border-blue-100 z-50">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center">
              <i className="ri-film-line text-white text-lg"></i>
            </div>
            <span className="text-2xl font-['Pacifico'] text-gray-800">GillC</span>
          </div>
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/editor" className="text-gray-600 hover:text-blue-600 transition-colors">Editor</Link>
            <Link href="/templates" className="text-gray-600 hover:text-blue-600 transition-colors">Templates</Link>
            <Link href="/gallery" className="text-gray-600 hover:text-blue-600 transition-colors">Gallery</Link>
            <Link href="/effects" className="text-gray-600 hover:text-blue-600 transition-colors">Effects</Link>
          </nav>
          <Link href="/editor" className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white px-6 py-2 !rounded-button hover:shadow-lg transition-all">
            Start Editing
          </Link>
        </div>
      </header>

      {/* Hero Section */}
      <section className="pt-24 pb-16 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <h1 className="text-5xl md:text-7xl font-bold text-gray-800 mb-6">
            Professional Video Editing
            <span className="block bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
              Completely Free
            </span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
            Create stunning videos with 400+ professional effects, 3D templates, AI-powered tools, and advanced timeline editing. Everything you need, absolutely free.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Link href="/editor" className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white px-8 py-4 !rounded-button text-lg hover:shadow-xl transition-all">
              <i className="ri-play-circle-line mr-2"></i>
              Start Creating
            </Link>
            <Link href="/gallery" className="bg-white/80 backdrop-blur-sm text-gray-700 px-8 py-4 !rounded-button text-lg border border-blue-200 hover:bg-white hover:shadow-lg transition-all">
              <i className="ri-gallery-line mr-2"></i>
              Browse Gallery
            </Link>
          </div>
          
          {/* Hero Video Preview */}
          <div className="relative max-w-4xl mx-auto">
            <div className="bg-gradient-to-r from-blue-500 to-indigo-600 p-1 rounded-2xl">
              <div className="bg-gray-900 rounded-xl overflow-hidden">
                <img 
                  src="https://readdy.ai/api/search-image?query=Professional%20video%20editing%20interface%20with%20timeline%20controls%2C%20multiple%20video%20tracks%2C%20preview%20window%2C%20modern%20dark%20theme%2C%20cinematic%20footage%20being%20edited%2C%20high-tech%20video%20editing%20software%2C%20sleek%20professional%20interface%2C%20blue%20accent%20colors%2C%20multiple%20layers%20visible&width=800&height=450&seq=hero-video&orientation=landscape"
                  alt="GillC Video Editor Interface"
                  className="w-full h-auto object-cover"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="bg-white/20 backdrop-blur-sm rounded-full p-4 hover:bg-white/30 transition-colors cursor-pointer">
                    <i className="ri-play-fill text-white text-3xl"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">
            Everything You Need for Professional Video Editing
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div 
                key={index}
                className="bg-white/60 backdrop-blur-sm p-6 rounded-xl border border-blue-100 hover:shadow-lg transition-all cursor-pointer"
                onMouseEnter={() => setActiveFeature(index)}
              >
                <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center mb-4">
                  <i className={`${feature.icon} text-white text-xl`}></i>
                </div>
                <h3 className="text-lg font-semibold text-gray-800 mb-2">{feature.title}</h3>
                <p className="text-gray-600 text-sm">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Key Features Showcase */}
      <section className="py-16 px-4 bg-gradient-to-r from-blue-500 to-indigo-600">
        <div className="max-w-6xl mx-auto">
          <div className="text-center text-white mb-12">
            <h2 className="text-3xl font-bold mb-4">Advanced Editing Tools</h2>
            <p className="text-blue-100 text-lg">Professional-grade features that rival premium software</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
              <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center mb-4">
                <i className="ri-scissors-cut-line text-white text-xl"></i>
              </div>
              <h3 className="text-white text-lg font-semibold mb-3">Timeline Editor</h3>
              <ul className="text-blue-100 text-sm space-y-2">
                <li>• Multi-track editing</li>
                <li>• Precision cutting tools</li>
                <li>• Audio sync controls</li>
                <li>• Speed adjustment (0.5x-3x)</li>
              </ul>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
              <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center mb-4">
                <i className="ri-palette-line text-white text-xl"></i>
              </div>
              <h3 className="text-white text-lg font-semibold mb-3">400+ Effects</h3>
              <ul className="text-blue-100 text-sm space-y-2">
                <li>• Motion Blur & HDR</li>
                <li>• Particle Systems</li>
                <li>• Color Grading</li>
                <li>• Cinematic Filters</li>
              </ul>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
              <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center mb-4">
                <i className="ri-cpu-line text-white text-xl"></i>
              </div>
              <h3 className="text-white text-lg font-semibold mb-3">AI Features</h3>
              <ul className="text-blue-100 text-sm space-y-2">
                <li>• Smart cutout tools</li>
                <li>• Frame interpolation</li>
                <li>• Auto-editing assist</li>
                <li>• Super resolution</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Effects Gallery Preview */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Professional Effects Library</h2>
            <p className="text-gray-600 text-lg">Browse our collection of 400+ meticulously crafted effects</p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 mb-8">
            {[
              'Motion Blur', 'HDR', 'Particle System', 'Cinematic', 'Vintage', 'Distortion',
              '3D Depth', 'Color Wheel', 'Edge Glow', 'Displacement', 'Turbulent', 'Swing'
            ].map((effect, index) => (
              <div key={index} className="bg-white/60 backdrop-blur-sm p-4 rounded-lg border border-blue-100 text-center hover:shadow-lg transition-all cursor-pointer">
                <div className="w-full h-16 bg-gradient-to-r from-blue-400 to-indigo-500 rounded-lg mb-2 overflow-hidden">
                  <img 
                    src={`https://readdy.ai/api/search-image?query=icon%2C%20video%20effect%20preview%20$%7Beffect.toLowerCase%28%29%7D%2C%20cinematic%20visual%20effect%20demonstration%2C%20professional%20video%20editing%20effect%2C%20sleek%20modern%20design%2C%20isolated%20on%20white%20background%2C%20centered%20composition&width=100&height=100&seq=effect-${index}&orientation=squarish`}
                    alt={effect}
                    className="w-full h-full object-cover"
                  />
                </div>
                <p className="text-xs text-gray-600 font-medium">{effect}</p>
              </div>
            ))}
          </div>
          
          <div className="text-center">
            <Link href="/effects" className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white px-6 py-3 !rounded-button hover:shadow-lg transition-all">
              <i className="ri-eye-line mr-2"></i>
              View All Effects
            </Link>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 px-4 bg-gradient-to-br from-gray-900 to-blue-900">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-white mb-4">
            Start Creating Amazing Videos Today
          </h2>
          <p className="text-blue-200 text-lg mb-8">
            Join thousands of creators using GillC for professional video editing - completely free, forever.
          </p>
          <Link href="/editor" className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white px-8 py-4 !rounded-button text-lg hover:shadow-xl transition-all inline-block">
            <i className="ri-rocket-line mr-2"></i>
            Launch Editor
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white/80 backdrop-blur-sm border-t border-blue-100 py-12 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center">
                  <i className="ri-film-line text-white text-lg"></i>
                </div>
                <span className="text-2xl font-['Pacifico'] text-gray-800">GillC</span>
              </div>
              <p className="text-gray-600 text-sm">Professional video editing made accessible for everyone.</p>
            </div>
            
            <div>
              <h4 className="font-semibold text-gray-800 mb-3">Editor</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li><Link href="/editor" className="hover:text-blue-600 transition-colors">Video Editor</Link></li>
                <li><Link href="/editor/3d" className="hover:text-blue-600 transition-colors">3D Editor</Link></li>
                <li><Link href="/editor/animation" className="hover:text-blue-600 transition-colors">Animation</Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-gray-800 mb-3">Resources</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li><Link href="/templates" className="hover:text-blue-600 transition-colors">Templates</Link></li>
                <li><Link href="/effects" className="hover:text-blue-600 transition-colors">Effects</Link></li>
                <li><Link href="/gallery" className="hover:text-blue-600 transition-colors">Gallery</Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-gray-800 mb-3">Community</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li><a href="#" className="hover:text-blue-600 transition-colors">Tutorials</a></li>
                <li><a href="#" className="hover:text-blue-600 transition-colors">Support</a></li>
                <li><a href="#" className="hover:text-blue-600 transition-colors">Feedback</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-blue-100 mt-8 pt-6 text-center">
            <p className="text-gray-600 text-sm">© 2024 GillC. Professional video editing, completely free.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
