
'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Gallery() {
  const [selectedCategory, setSelectedCategory] = useState('trending');

  const categories = [
    { id: 'trending', name: 'Trending', icon: 'ri-fire-line' },
    { id: 'featured', name: 'Featured', icon: 'ri-star-line' },
    { id: 'recent', name: 'Recent', icon: 'ri-time-line' },
    { id: 'cinematic', name: 'Cinematic', icon: 'ri-movie-2-line' },
    { id: 'music-videos', name: 'Music Videos', icon: 'ri-music-line' },
    { id: 'tutorials', name: 'Tutorials', icon: 'ri-play-circle-line' },
    { id: 'shorts', name: 'Shorts', icon: 'ri-smartphone-line' },
    { id: 'animations', name: 'Animations', icon: 'ri-magic-line' }
  ];

  const videos = [
    {
      id: 1,
      title: 'Epic Cinematic Trailer',
      creator: 'ProEditor',
      duration: '2:15',
      views: '125K',
      likes: '8.2K',
      category: 'cinematic',
      thumbnail: 'epic-cinematic-trailer-dramatic-scenes-professional'
    },
    {
      id: 2,
      title: 'Smooth Music Video Edit',
      creator: 'BeatCreator',
      duration: '3:42',
      views: '89K',
      likes: '6.7K',
      category: 'music-videos',
      thumbnail: 'music-video-edit-smooth-transitions-colorful'
    },
    {
      id: 3,
      title: '3D Logo Animation Tutorial',
      creator: 'DesignMaster',
      duration: '5:28',
      views: '67K',
      likes: '4.1K',
      category: 'tutorials',
      thumbnail: '3d-logo-animation-tutorial-professional-design'
    },
    {
      id: 4,
      title: 'Quick Mobile Short',
      creator: 'ShortFilm',
      duration: '0:45',
      views: '156K',
      likes: '12.3K',
      category: 'shorts',
      thumbnail: 'mobile-short-film-quick-edit-vertical'
    },
    {
      id: 5,
      title: 'Particle Effects Showcase',
      creator: 'VFXArtist',
      duration: '1:52',
      views: '98K',
      likes: '7.5K',
      category: 'animations',
      thumbnail: 'particle-effects-showcase-visual-effects'
    },
    {
      id: 6,
      title: 'Color Grading Masterclass',
      creator: 'ColorGuru',
      duration: '8:15',
      views: '234K',
      likes: '18.9K',
      category: 'tutorials',
      thumbnail: 'color-grading-masterclass-professional-editing'
    },
    {
      id: 7,
      title: 'Urban Street Photography',
      creator: 'StreetView',
      duration: '2:33',
      views: '78K',
      likes: '5.6K',
      category: 'cinematic',
      thumbnail: 'urban-street-photography-cinematic-style'
    },
    {
      id: 8,
      title: 'Beat Drop Synchronization',
      creator: 'SyncMaster',
      duration: '3:18',
      views: '145K',
      likes: '11.2K',
      category: 'music-videos',
      thumbnail: 'beat-drop-synchronization-music-visualization'
    },
    {
      id: 9,
      title: 'Motion Graphics Demo',
      creator: 'MotionPro',
      duration: '1:24',
      views: '92K',
      likes: '6.8K',
      category: 'animations',
      thumbnail: 'motion-graphics-demo-professional-animation'
    }
  ];

  const filteredVideos = videos.filter(video => 
    selectedCategory === 'trending' || 
    selectedCategory === 'featured' || 
    selectedCategory === 'recent' || 
    video.category === selectedCategory
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      {/* Header */}
      <header className="bg-black/20 backdrop-blur-lg border-b border-white/10 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center">
                <i className="ri-film-line text-white text-lg"></i>
              </div>
              <span className="text-2xl font-['Pacifico'] text-white">GillC</span>
            </Link>
            <div className="hidden md:block text-purple-200">Community Gallery</div>
          </div>
          
          <div className="flex items-center space-x-4">
            <Link href="/editor" className="text-purple-200 hover:text-white transition-colors">
              <i className="ri-edit-line mr-2"></i>Create Video
            </Link>
            <button className="bg-gradient-to-r from-purple-500 to-indigo-600 text-white px-6 py-2 !rounded-button hover:shadow-lg transition-all">
              <i className="ri-upload-line mr-2"></i>Upload
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="text-center mb-8">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">
            Community Gallery
          </h1>
          <p className="text-xl text-purple-200 mb-6 max-w-3xl mx-auto">
            Discover amazing videos created by the GillC community. Get inspired, learn new techniques, 
            and share your own creations.
          </p>
        </div>

        {/* Category Tabs */}
        <div className="flex flex-wrap gap-2 mb-8 justify-center">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`flex items-center space-x-2 px-4 py-2 !rounded-button transition-all ${
                selectedCategory === category.id
                  ? 'bg-gradient-to-r from-purple-500 to-indigo-600 text-white shadow-lg'
                  : 'bg-white/10 backdrop-blur-sm text-purple-200 hover:bg-white/20'
              }`}
            >
              <i className={category.icon}></i>
              <span>{category.name}</span>
            </button>
          ))}
        </div>

        {/* Featured Video */}
        {selectedCategory === 'trending' && (
          <div className="mb-12">
            <div className="bg-gradient-to-r from-purple-600/20 to-indigo-600/20 backdrop-blur-sm rounded-2xl border border-white/10 overflow-hidden">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 p-8">
                <div className="aspect-video bg-gradient-to-br from-purple-600 to-indigo-700 rounded-xl relative overflow-hidden">
                  <img 
                    src="https://readdy.ai/api/search-image?query=trending-featured-video-cinematic-masterpiece-professional-editing-viral-content-high-quality-video-production&width=600&height=337&seq=featured-video&orientation=landscape"
                    alt="Featured Video"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <button className="bg-white/20 backdrop-blur-sm rounded-full p-4 hover:bg-white/30 transition-colors">
                      <i className="ri-play-fill text-white text-3xl"></i>
                    </button>
                  </div>
                  <div className="absolute top-4 left-4 bg-red-500 text-white text-xs px-2 py-1 rounded-full font-medium animate-pulse">
                    TRENDING #1
                  </div>
                </div>
                <div className="flex flex-col justify-center">
                  <h3 className="text-3xl font-bold text-white mb-4">Cinematic Masterpiece</h3>
                  <p className="text-purple-200 text-lg mb-4">
                    An incredible showcase of professional video editing techniques, featuring advanced 
                    color grading, smooth transitions, and stunning visual effects.
                  </p>
                  <div className="flex items-center space-x-6 text-purple-200 mb-6">
                    <div className="flex items-center space-x-2">
                      <i className="ri-eye-line"></i>
                      <span>1.2M views</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <i className="ri-heart-line"></i>
                      <span>89K likes</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <i className="ri-time-line"></i>
                      <span>4:32</span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <button className="bg-gradient-to-r from-purple-500 to-indigo-600 text-white px-6 py-3 !rounded-button hover:shadow-lg transition-all">
                      <i className="ri-play-fill mr-2"></i>Watch Now
                    </button>
                    <button className="bg-white/10 backdrop-blur-sm text-white px-6 py-3 !rounded-button border border-white/20 hover:bg-white/20 transition-all">
                      <i className="ri-heart-line mr-2"></i>Like
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Videos Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredVideos.map((video) => (
            <div
              key={video.id}
              className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 overflow-hidden hover:border-purple-400/50 transition-all group cursor-pointer"
            >
              {/* Video Thumbnail */}
              <div className="aspect-video bg-gradient-to-br from-purple-600 to-indigo-700 relative overflow-hidden">
                <img 
                  src={`https://readdy.ai/api/search-image?query=$%7Bvideo.thumbnail%7D%2C%20video%20thumbnail%2C%20professional%20video%20editing%2C%20community%20content%2C%20high-quality%20video&width=400&height=225&seq=video-${video.id}&orientation=landscape`}
                  alt={video.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <button className="bg-white/20 backdrop-blur-sm rounded-full p-3 hover:bg-white/30 transition-colors">
                      <i className="ri-play-fill text-white text-xl"></i>
                    </button>
                  </div>
                </div>
                <div className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
                  {video.duration}
                </div>
              </div>

              {/* Video Info */}
              <div className="p-4">
                <h3 className="text-white font-semibold mb-2 line-clamp-2">{video.title}</h3>
                <p className="text-purple-300 text-sm mb-3">by {video.creator}</p>
                
                <div className="flex items-center justify-between text-xs text-purple-200">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-1">
                      <i className="ri-eye-line"></i>
                      <span>{video.views}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <i className="ri-heart-line"></i>
                      <span>{video.likes}</span>
                    </div>
                  </div>
                  <button className="text-purple-300 hover:text-white transition-colors">
                    <i className="ri-more-line"></i>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Load More */}
        <div className="text-center mt-12">
          <button className="bg-white/10 backdrop-blur-sm text-white px-8 py-3 !rounded-button border border-white/20 hover:bg-white/20 transition-all">
            Load More Videos
          </button>
        </div>

        {/* Upload CTA */}
        <section className="mt-16">
          <div className="bg-gradient-to-r from-purple-600/20 to-indigo-600/20 backdrop-blur-sm rounded-2xl border border-white/10 p-8 text-center">
            <h2 className="text-3xl font-bold text-white mb-4">Share Your Creations</h2>
            <p className="text-purple-200 mb-6 max-w-2xl mx-auto">
              Join thousands of creators sharing their work. Upload your videos, get feedback, 
              and inspire others with your editing skills.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-gradient-to-r from-purple-500 to-indigo-600 text-white px-8 py-3 !rounded-button hover:shadow-lg transition-all">
                <i className="ri-upload-line mr-2"></i>
                Upload Video
              </button>
              <Link href="/editor" className="bg-white/10 backdrop-blur-sm text-white px-8 py-3 !rounded-button border border-white/20 hover:bg-white/20 transition-all">
                <i className="ri-edit-line mr-2"></i>
                Create New
              </Link>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
