
'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Templates() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  
  const categories = [
    { id: 'all', name: 'All Templates', count: 150 },
    { id: '3d-intros', name: '3D Intros', count: 25 },
    { id: 'logo-reveals', name: 'Logo Reveals', count: 30 },
    { id: 'text-animations', name: 'Text Animations', count: 35 },
    { id: 'transitions', name: 'Transitions', count: 20 },
    { id: 'particles', name: 'Particle Effects', count: 15 },
    { id: 'cinematic', name: 'Cinematic', count: 25 }
  ];

  const templates = [
    {
      id: 1,
      name: 'Cinematic Logo Reveal',
      category: '3d-intros',
      duration: '5s',
      description: 'Professional 3D logo animation with particle effects',
      preview: 'cinematic-3d-logo-reveal-animation-professional'
    },
    {
      id: 2,
      name: 'Glitch Text Intro',
      category: 'text-animations',
      duration: '3s',
      description: 'Modern glitch-style text animation',
      preview: 'glitch-text-animation-modern-digital-effect'
    },
    {
      id: 3,
      name: 'Particle Explosion',
      category: 'particles',
      duration: '4s',
      description: 'Dynamic particle explosion with trails',
      preview: 'particle-explosion-dynamic-visual-effect'
    },
    {
      id: 4,
      name: 'Smooth Slide Transition',
      category: 'transitions',
      duration: '2s',
      description: 'Elegant sliding transition between scenes',
      preview: 'smooth-slide-transition-elegant-video-effect'
    },
    {
      id: 5,
      name: 'Corporate Logo Build',
      category: 'logo-reveals',
      duration: '6s',
      description: 'Professional corporate logo build-up animation',
      preview: 'corporate-logo-build-professional-animation'
    },
    {
      id: 6,
      name: 'Film Noir Intro',
      category: 'cinematic',
      duration: '8s',
      description: 'Classic film noir style opening sequence',
      preview: 'film-noir-intro-classic-cinematic-style'
    },
    {
      id: 7,
      name: 'Neon Text Glow',
      category: 'text-animations',
      duration: '4s',
      description: 'Vibrant neon text with pulsing glow effects',
      preview: 'neon-text-glow-vibrant-animation-effect'
    },
    {
      id: 8,
      name: 'Geometric Logo Reveal',
      category: 'logo-reveals',
      duration: '5s',
      description: 'Modern geometric shapes forming logo',
      preview: 'geometric-logo-reveal-modern-animation'
    },
    {
      id: 9,
      name: 'Fire Particle System',
      category: 'particles',
      duration: '6s',
      description: 'Realistic fire and smoke particle effects',
      preview: 'fire-particle-system-realistic-effect'
    }
  ];

  const filteredTemplates = templates.filter(template => 
    selectedCategory === 'all' || template.category === selectedCategory
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-blue-900">
      {/* Header */}
      <header className="bg-black/20 backdrop-blur-lg border-b border-white/10 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center">
                <i className="ri-film-line text-white text-lg"></i>
              </div>
              <span className="text-2xl font-['Pacifico'] text-white">GillC</span>
            </Link>
            <div className="hidden md:block text-purple-200">3D Templates & Animations</div>
          </div>
          
          <div className="flex items-center space-x-4">
            <Link href="/editor" className="bg-gradient-to-r from-purple-500 to-indigo-600 text-white px-6 py-2 !rounded-button hover:shadow-lg transition-all">
              <i className="ri-edit-line mr-2"></i>
              Open Editor
            </Link>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">
            🎬 3D Templates & Editor
          </h1>
          <p className="text-xl text-purple-200 mb-8 max-w-3xl mx-auto">
            Professional 3D templates including logo reveals, text animations, and particle effects. 
            Create stunning intros and animations with our advanced 3D editor.
          </p>
        </div>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Categories */}
          <div className="lg:w-64">
            <div className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6 sticky top-24">
              <h3 className="text-white font-semibold mb-4">Template Categories</h3>
              <div className="space-y-2">
                {categories.map((category) => (
                  <button
                    key={category.id}
                    onClick={() => setSelectedCategory(category.id)}
                    className={`w-full text-left flex items-center justify-between px-3 py-2 rounded-lg transition-colors ${
                      selectedCategory === category.id
                        ? 'bg-gradient-to-r from-purple-500 to-indigo-600 text-white'
                        : 'text-purple-200 hover:bg-white/10'
                    }`}
                  >
                    <span className="text-sm">{category.name}</span>
                    <span className="text-xs opacity-70">{category.count}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Templates Grid */}
          <div className="flex-1">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-white">
                {selectedCategory === 'all' ? 'All Templates' : categories.find(c => c.id === selectedCategory)?.name}
              </h2>
              <div className="text-purple-200">
                {filteredTemplates.length} templates
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredTemplates.map((template) => (
                <div
                  key={template.id}
                  className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 overflow-hidden hover:border-purple-400/50 transition-all group cursor-pointer"
                >
                  {/* Template Preview */}
                  <div className="aspect-video bg-gradient-to-br from-purple-600 to-indigo-700 relative overflow-hidden">
                    <img 
                      src={`https://readdy.ai/api/search-image?query=$%7Btemplate.preview%7D%2C%20professional%203D%20animation%20template%2C%20high-quality%20video%20template%2C%20modern%20animation%20design%2C%20cinematic%20template&width=400&height=225&seq=template-${template.id}&orientation=landscape`}
                      alt={template.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                      <div className="absolute inset-0 flex items-center justify-center">
                        <button className="bg-white/20 backdrop-blur-sm rounded-full p-3 hover:bg-white/30 transition-colors">
                          <i className="ri-play-fill text-white text-xl"></i>
                        </button>
                      </div>
                    </div>
                    <div className="absolute top-3 right-3 bg-purple-500 text-white text-xs px-2 py-1 rounded-full font-medium">
                      {template.duration}
                    </div>
                    <div className="absolute top-3 left-3 bg-green-500 text-white text-xs px-2 py-1 rounded-full font-medium">
                      FREE
                    </div>
                  </div>

                  {/* Template Info */}
                  <div className="p-4">
                    <h3 className="text-white font-semibold mb-2">{template.name}</h3>
                    <p className="text-purple-200 text-sm mb-3">{template.description}</p>
                    
                    <div className="flex items-center justify-between">
                      <div className="text-xs text-purple-300 capitalize">
                        {categories.find(c => c.id === template.category)?.name}
                      </div>
                      <button className="bg-gradient-to-r from-purple-500 to-indigo-600 text-white px-4 py-2 !rounded-button text-sm hover:shadow-lg transition-all">
                        Use Template
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* 3D Editor Section */}
        <section className="mt-16">
          <div className="bg-gradient-to-r from-purple-600/20 to-indigo-600/20 backdrop-blur-sm rounded-2xl border border-white/10 p-8">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-white mb-4">Advanced 3D Editor</h2>
              <p className="text-purple-200 mb-6 max-w-2xl mx-auto">
                Professional 3D editing tools with depth controls, rotation, and advanced lighting. 
                Create custom 3D animations and effects.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10">
                <div className="w-12 h-12 bg-purple-500 rounded-lg flex items-center justify-center mb-4">
                  <i className="ri-3d-view-line text-white text-xl"></i>
                </div>
                <h3 className="text-white font-semibold mb-2">3D Depth Controls</h3>
                <p className="text-purple-200 text-sm">
                  Professional depth and rotation controls for creating realistic 3D effects
                </p>
              </div>

              <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10">
                <div className="w-12 h-12 bg-indigo-500 rounded-lg flex items-center justify-center mb-4">
                  <i className="ri-flashlight-line text-white text-xl"></i>
                </div>
                <h3 className="text-white font-semibold mb-2">Advanced Lighting</h3>
                <p className="text-purple-200 text-sm">
                  Dynamic lighting system with shadows, reflections, and ambient lighting
                </p>
              </div>

              <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10">
                <div className="w-12 h-12 bg-blue-500 rounded-lg flex items-center justify-center mb-4">
                  <i className="ri-settings-3-line text-white text-xl"></i>
                </div>
                <h3 className="text-white font-semibold mb-2">Custom Keyframes</h3>
                <p className="text-purple-200 text-sm">
                  Precision control over animation curves and timing with custom keyframes
                </p>
              </div>
            </div>

            <div className="text-center mt-8">
              <Link href="/editor/3d" className="bg-gradient-to-r from-purple-500 to-indigo-600 text-white px-8 py-3 !rounded-button hover:shadow-lg transition-all">
                <i className="ri-cube-line mr-2"></i>
                Open 3D Editor
              </Link>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
